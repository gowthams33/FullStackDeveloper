package com.json.genson;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.json.method.JsonMethod;
import com.owlike.genson.Genson;

@SuppressWarnings("rawtypes")

public class JsonGensonJar extends JsonMethod {

	private Map inputMap = new HashMap<>();
	private List inputList = new ArrayList<>();
	
	@Override
	public List getArrayValue(StringBuffer fileLocation) {

		File file = new File("" + fileLocation);
		try {
			inputList = new Genson().deserialize(new FileReader(file), List.class);
			for (Object object : inputList) {
				if (object instanceof Map)
					System.currentTimeMillis();
					
			}

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
		return inputList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Map getJsonValue(File fileLocation) {

		Map directMap;
		try {

			directMap = new Genson().deserialize(new FileReader(fileLocation), Map.class);

			for (Object key : directMap.keySet()) {
				if (directMap.get(key) instanceof Map)
					for (Object subkey : ((Map) directMap.get(key)).keySet())
						if (((Map) directMap.get(key)).get(subkey) instanceof Map)
							inputMap.putAll((Map) ((Map) directMap.get(key)).get(subkey));
						else
							inputMap.put(subkey, ((Map) directMap.get(key)).get(subkey));
				else
					inputMap.put(key, directMap.get(key));
			}

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}

		return inputMap;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void nestedJsonValueMethod(Object keyValue, Map nestedMap) {
		for (Object key : nestedMap.keySet()) {
			if (nestedMap.get(key) instanceof Map)
				nestedJsonValueMethod(key, (Map) nestedMap.get(key));
			else
				inputMap.put(keyValue, nestedMap);
		}
	}

	@Override
	public void nestedJsonValueMethod(Object indexPosition, ArrayList<String> nestedList) {

		for (Object object : nestedList.toArray()) {
			if (object instanceof List)
				nestedJsonValueMethod(indexPosition, nestedList);
			else if (object instanceof Map)
				nestedJsonValueMethod(object, nestedList);
			else
				nestedList.add(object.toString());

		}
	}

	/*
	 * public void advance(File arg0) {
	 * 
	 * try {
	 * 
	 * byte[] values = Files.readAllBytes(Paths.get(arg0.getAbsolutePath()));
	 * String string = new String(values);
	 * 
	 * JSONNavi<Map> map = new JSONNavi<Map>(string); for (String key :
	 * map.getKeys()) { if (map.get(key) instanceof Map) nestedMethod(key, (Map)
	 * map.get(key));
	 * 
	 * }
	 * 
	 * } catch (IOException e) { e.printStackTrace(); } }
	 */
}
