package com.json.mjson;


import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.json.method.JsonMethod;

import mjson.Json;

public class Mjson extends JsonMethod {
	
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public Map getJsonValue(File reader) {
		Map<String, String> map = new HashMap<>();
		String temp = "";
		try {

			List<String> list = Files.readAllLines(Paths.get(reader.getAbsolutePath()));
			for (String string : list) {
				temp += string;
			}

			Map map1 = Json.read(temp).asJsonMap();

			map = new Mjson().advance(map1);
			for(String key : map.keySet()){
				map.replace(key, map.get(key), map.get(key).substring(1, map.get(key).length()-1));
			}
		} catch (IOException e) {
			e.printStackTrace();

		}

		return map;
	}
	

	@SuppressWarnings({ "rawtypes" })
	public Map advance(Map map1) {
		Map<String, String> temp = new HashMap<>();
		for (Object object : map1.keySet()) {
			if (map1.get(object.toString()) instanceof Object) {
				Json list = Json.read("" + map1.get(object.toString())).dup();

				if (list.isObject()) {
					for (Object obj : list.asJsonMap().keySet())
						if (!list.asJsonMap().get(obj).isObject())
							temp.put(obj.toString(), (String)list.asJsonMap().get(obj).toString());
						else
							for(Object nested : list.asJsonMap().get(obj).asJsonMap().keySet())
								temp.put(nested.toString(),(String)list.asJsonMap().get(obj).asJsonMap().get(nested).toString());
				} else
					temp.put(object.toString(), (String)list.toString());

			}

		}
		
		return temp;

	}

	
	@SuppressWarnings("rawtypes")
	@Override
	public void nestedJsonValueMethod(Object object, Map map) {
		/*
		 * JSONObject jsonObject1 = (JSONObject) object;
		 * 
		 * for (Object o : jsonObject1.keySet()) {
		 * 
		 * if (jsonObject1.get(o.toString()) instanceof JSONObject) {
		 * 
		 * nestedMethod((JSONObject) jsonObject1.get(o.toString()), map); } else
		 * if (jsonObject1.get(o.toString()) instanceof JSONArray) { new
		 * Mjson().getArrayValue(new StringBuffer("" +
		 * jsonObject1.get(o.toString()))); } else { map.put(o.toString(), "" +
		 * jsonObject1.get(o.toString()));
		 * 
		 * }
		 * 
		 * }
		 * 
		 */ }

	@Override
	public void nestedJsonValueMethod(Object object, ArrayList<String> list) {
		//
	}

	

	@SuppressWarnings("rawtypes")
	@Override
	public List getArrayValue(StringBuffer buffer) {

		return null;
	}



}
