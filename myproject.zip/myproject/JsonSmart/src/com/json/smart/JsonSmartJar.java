package com.json.smart;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.json.method.JsonMethod;

import net.minidev.json.JSONNavi;
import net.minidev.json.JSONObject;
import net.minidev.json.JSONValue;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException;

@SuppressWarnings({ "rawtypes", "unchecked" })
public class JsonSmartJar extends JsonMethod {

	public Map inputMap = new HashMap<>();
	public List inputList = new ArrayList<>();

	
	@SuppressWarnings({ "static-access", "deprecation" })
	@Override
	public List getArrayValue(StringBuffer fileLocation) {

		File file = new File("" + fileLocation);
		try {
			StringBuffer temp = new StringBuffer();
			List list = new ArrayList<>();
			String stringFormat = new String(Files.readAllBytes(Paths.get(file.getAbsolutePath())));
			JSONParser parser = new JSONParser();
			JSONObject jsonObject = (JSONObject) parser.parse(stringFormat);
			for (Object object : jsonObject.keySet()) {
				if (jsonObject.get(object) instanceof JSONObject)
					new JSONValue().writeJSONString(jsonObject.get(object), temp);
				else
					list.add(jsonObject.get(object));
			}

			fileLocation = new StringBuffer();
			JSONObject jsonObject2 = (JSONObject) parser.parse("" + temp);
			for (Object object : jsonObject2.keySet()) {
				if (jsonObject2.get(object) instanceof JSONObject)
					new JSONValue().writeJSONString(jsonObject2.get(object), fileLocation);
				else
					list.add(jsonObject2.get(object));
			}

			if (fileLocation.length() != 0) {
				JSONObject jsonObject1 = (JSONObject) parser.parse("" + fileLocation);
				for (Object object : jsonObject1.keySet()) {
					if (jsonObject1.get(object) instanceof JSONObject)
						new JSONValue().writeJSONString(jsonObject1.get(object), fileLocation);
					else
						list.add(jsonObject1.get(object));
				}
			}

			inputList = list;
		} catch (IOException | ParseException e) {

			e.printStackTrace();
		}

		return inputList;
	}

	@Override
	public Map getJsonValue(File fileLocation) {
		try {

			byte[] values = Files.readAllBytes(Paths.get(fileLocation.getAbsolutePath()));
			String string = new String(values);

			JSONNavi<Map> map = new JSONNavi<Map>(string);
			for (String key : map.getKeys()) {
				if (map.get(key) instanceof Map)
					nestedJsonValueMethod(key, (Map) map.get(key));
				else
					inputMap.put(key, map.get(key));

			}

		} catch (IOException e) {
			e.printStackTrace();
		}
		return inputMap;
	}

	@Override
	public void nestedJsonValueMethod(Object keyValue, Map nestedMap) {
		for (Object key : nestedMap.keySet()) {
			if (nestedMap.get(key) instanceof Map)
				nestedJsonValueMethod(key, (Map) nestedMap.get(key));
			else
				inputMap.put(key, nestedMap.get(key));
		}

	}

	@Override
	public void nestedJsonValueMethod(Object keyobject, ArrayList<String> nestedArray) {

	}

}
