package com.Json.check;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.Json.validation.ValidationCheck;
import com.json.genson.JsonGensonJar;
import com.json.gson.JsonGsonJar;
import com.json.mjson.Mjson;
import com.json.simple.JsonSimpleJar;
import com.json.smart.JsonSmartJar;

@SuppressWarnings("rawtypes")
public class JsonCheck {

	public Map inputMap = null;

	public Map validationMap = null;

	/**
	 * 
	 * @param object
	 * @param read
	 * @return Get Input Files and Validation file
	 */

	public ArrayList<String> jsonMethodCheck(Object object, File input, File validation) {

		try {
			inputMap = new HashMap<>();

			inputMap = (Map) getSimpleJar(object, input);
		
			// validationMap = ValidationCheck.input(new
			// FileReader(validation));

			File file = new File(validation.getPath() + ".txt");
			
			if (file.createNewFile() || (new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(validation.lastModified()).compareTo(new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(file.lastModified())) > 0)) {

				FileOutputStream outputStream = new FileOutputStream(file);
				ObjectOutputStream outputStream2 = new ObjectOutputStream(outputStream);
				validationMap = ValidationCheck.input(new FileReader(validation));

				outputStream2.writeObject(validationMap);
				outputStream2.close();
			} else {

				FileInputStream inputStream = new FileInputStream(file);
				ObjectInputStream inputStream2 = new ObjectInputStream(inputStream);
				validationMap = (Map) inputStream2.readObject();

				inputStream.close();
				inputStream2.close();

			}

		} catch (IOException | ClassNotFoundException e) {

			e.printStackTrace();
		}

		return ValidationCheck.ValidationFiles(inputMap, validationMap);
	}

	/**
	 * 
	 * @param obj
	 * @param read
	 * @return Output File From Client and Send it Json jar Classes!
	 */

	public static Map getSimpleJar(Object obj, File fileName) {
		Map inputMap = new HashMap<>();

		try {
			if (obj instanceof JsonSimpleJar) {

				JsonSimpleJar jsonSimple = new JsonSimpleJar();
				inputMap = (Map) jsonSimple.getJsonValue(fileName);
			} else if (obj instanceof JsonGsonJar) {
				JsonGsonJar jsonGson = new JsonGsonJar();
				inputMap = (Map) jsonGson.getJsonValue(fileName);
			} else if (obj instanceof Mjson) {
				Mjson mjson = new Mjson();
				inputMap = mjson.getJsonValue(fileName);
			} else if (obj instanceof JsonGensonJar) {
				JsonGensonJar genson = new JsonGensonJar();
				inputMap = genson.getJsonValue(fileName);
			} else if (obj instanceof JsonSmartJar) {
				JsonSmartJar smartJson = new JsonSmartJar();
				inputMap = smartJson.getJsonValue(fileName);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return inputMap;

	}

	public ArrayList<String> jsonMethodCheck(Object object, String input, File validation) {

		try {
			inputMap = new HashMap<>();

			inputMap = (Map) getSimpleJar(object, input);
			
			// validationMap = ValidationCheck.input(new
			// FileReader(validation));

			File file = new File(validation.getPath() + ".txt");
			
			if (file.createNewFile() || (new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(validation.lastModified()).compareTo(new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(file.lastModified())) > 0)) {

				FileOutputStream outputStream = new FileOutputStream(file);
				ObjectOutputStream outputStream2 = new ObjectOutputStream(outputStream);
				validationMap = ValidationCheck.input(new FileReader(validation));

				outputStream2.writeObject(validationMap);
				outputStream2.close();
			} else {
				
				FileInputStream inputStream = new FileInputStream(file);
				ObjectInputStream inputStream2 = new ObjectInputStream(inputStream);
				validationMap = (Map) inputStream2.readObject();

				inputStream.close();
				inputStream2.close();

			}

		} catch (IOException | ClassNotFoundException e) {

			e.printStackTrace();
		}

		/*
		 * inputMap = new HashMap<>(); validationMap = new HashMap<>(); inputMap
		 * = (Map) getSimpleJar(object, input);
		 * 
		 * try { validationMap = ValidationCheck.input(new
		 * FileReader(validation)); } catch (FileNotFoundException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); }
		 */return ValidationCheck.ValidationFiles(inputMap, validationMap);
	}

	private Map getSimpleJar(Object object, String input) {
		Map inputMap = new HashMap<>();

		if (object instanceof JsonSimpleJar) {

			JsonSimpleJar jsonSimple = new JsonSimpleJar();
			inputMap = (Map) jsonSimple.getJsonValue(input);
		}
		return inputMap;
	}
}
