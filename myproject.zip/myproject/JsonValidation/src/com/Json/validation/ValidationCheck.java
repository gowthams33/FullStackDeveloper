package com.Json.validation;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

@SuppressWarnings({ "unchecked", "rawtypes" })
public class ValidationCheck {

	public static ArrayList<String> exceptionList = null;

	public static ArrayList<String> a = null;

	/**
	 * 
	 * @param read
	 * @return Get Input File From Client
	 */

	// validation is parse by simple json jar.

	public static Map input(FileReader fileName) {
		Map validationJsonValue = new HashMap<>();
		Map validationArrayValue = new HashMap<>();
		JSONParser jsonParser = new JSONParser();
		try {
			JSONObject jsonParseObject = (JSONObject) jsonParser.parse(fileName);

			for (Object keys : jsonParseObject.keySet()) {

				if (jsonParseObject.get(keys.toString()) instanceof JSONObject) {

					inputvalidation((JSONObject) jsonParseObject.get(keys.toString()), validationJsonValue);

				} else if (jsonParseObject.get(keys.toString()) instanceof JSONArray) {

					if (validationJsonValue.get(keys.toString()) == null)
						validationJsonValue.put(keys.toString(), jsonParseObject.get(keys.toString()));
					else {

						validationArrayValue.put(keys.toString(), jsonParseObject.get(keys.toString()));
						ArrayList listone = (ArrayList) validationArrayValue.get(keys.toString());
						String inputSchema = "" + validationJsonValue.get(keys.toString());
						listone.add(inputSchema.replace("[\"", "").replace("\"]", ""));

						validationJsonValue.put(keys.toString(), listone);

					}

				} else
					validationJsonValue.put(keys.toString(), jsonParseObject.get(keys.toString()));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return validationJsonValue;

	}

	/**
	 * 
	 * @param jsonobject
	 * @param map
	 *            Input File Into Mapping!
	 */

	public static void inputvalidation(JSONObject jsonobject, Map nestedJsonValue) {

		String object = "";

		for (Object keys : jsonobject.keySet()) {

			if (jsonobject.get(keys.toString()) instanceof JSONObject) {
				object = keys.toString();
				inputvalidation((JSONObject) jsonobject.get(keys.toString()), nestedJsonValue);
			}
			nestedJsonValue.put(object, jsonobject.get(object));

		}

	}

	/**
	 * Validation of Output File
	 * 
	 * @throws JSException
	 */

	public static ArrayList<String> ValidationFiles(Map inputMap, Map validationMap) {

		int checkDigit = 1;
		String validationString = new String();
		String inputSchema = new String();
		String result = new String();

		Map changeMap = new HashMap<>();
		Map<String, Map> valueChangeMap = new HashMap<>();
		Map validationValueMap = new HashMap<>();

		exceptionList = new ArrayList<>();

		for (Object keys : inputMap.keySet()) {
			checkDigit = 1;
			inputSchema = "" + inputMap.get(keys).toString();

			JSONObject jsonParseObject = new JSONObject((Map) validationMap.get(keys.toString()));

			for (Object object1 : jsonParseObject.keySet()) {

				changeMap.put(object1.toString(), jsonParseObject.get(object1.toString()));

			}

			if (jsonParseObject.keySet().size() != changeMap.keySet().size()) {
				changeMap.remove(new ArrayList<>(changeMap.keySet()).get(changeMap.size() - 1));
			}
			valueChangeMap.put(keys.toString(), changeMap);
			validationValueMap = valueChangeMap.get(keys.toString());

			// minLength-->0,pattern-->1,description-->2,id-->3,type-->4,maxLength-->5,enum-->6

			for (Object obj : validationValueMap.keySet()) {

				if (obj.equals("enum")) {

					JSONArray array = (JSONArray) validationValueMap.get(obj);
					for (int i = 0; i < array.size(); i++) {
						if (inputSchema.equals(array.get(i))) {
							checkDigit = 0;
							break;
						}
					}
					if (checkDigit == 0)
						checkDigit = 1;
					else {
						checkDigit = 0;
						result += (String) keys + " ";
					}
				} else if (obj.equals("pattern")) {
					validationString = (String) validationValueMap.get(obj);

					if (!Pattern.matches(validationString, inputSchema)) {

						checkDigit = 0;
						result += (String) keys + " ";
						break;
					}

				} else if (obj.equals("type")) {
					if (!(inputMap.get(keys) instanceof String))
						result += (String) keys + " ";
				}

			}
		}
		if (result.length() != 0) {
			for (String faildKey : result.split(" "))
				exceptionList.add(faildKey + " Invaild data");
		}

		changeMap = new HashMap<>();

		ArrayList<String> requiredList = (ArrayList) validationMap.get("required");
		for (int i = 0; i < requiredList.size(); i++) {

			if (inputMap.get(requiredList.get(i)) == null) {
				a = new ArrayList<>();
				if (validationMap.get(requiredList.get(i)) instanceof JSONObject) {
					
					JSONObject object = new JSONObject((Map) (validationMap.get(requiredList.get(i))));
					requiredValidation(object, changeMap);

					if (a.size() != 0) {
						for (String mand : a)
							if (inputMap.get(mand) == null)
								exceptionList.add(mand + " RMissing Tag");
					} else {
						
						exceptionList.add(requiredList.get(i) + " Missing Tag");
					}
				}
			}
		}

		return exceptionList;
	}

	private static void requiredValidation(JSONObject jsonobject, Map changeMap) {
		String object = "";

		for (Object keys : jsonobject.keySet()) {

			if (jsonobject.get(keys.toString()) instanceof JSONObject) {

				object = keys.toString();
				requiredValidation((JSONObject) jsonobject.get(keys.toString()), changeMap);
			} else if (jsonobject.get(keys) instanceof JSONArray) {
				if (keys.equals("required"))
					a.addAll((ArrayList) jsonobject.get(keys));

			} else
				changeMap.put(object, jsonobject.get(object));

		}

	}

}

/*
 * if(keys.equals("dateAndTime") && !result.contains("dateAndTime")){ if
 * (isLegalDate(inputSchema, "MMddHHmmss")) fd.message.addInDeMap(7,
 * inputSchema); else { fd.message.addInDeMap(39,
 * ResCode.resCode.get(respCodeStr + keys)); log.info(corrId +
 * "Illegal data in Tag dateAndTime"); } }
 */

/*
 *
 * 
 * 
 * int checkDigit = 1; String validationString = new String(); String
 * inputSchema = new String(); String result = null; String respCodeStr =
 * "ResCode."; String routingEntity = null; String txnType = null; String
 * accType = "00"; NetworkRouting networkRouting = null; char msgType = '\0';
 * routingEntity = (String) inputMap.get("routingEntity"); txnType = (String)
 * inputMap.get("transType"); accType = (String) inputMap.get("accType");
 * 
 * Map changeMap = new HashMap<>(); Map<String, Map> valueChangeMap = new
 * HashMap<>(); Map validationValueMap = new HashMap<>();
 * 
 * FieldData fd = new FieldData();
 * 
 * exceptionList = new ArrayList<>();
 * 
 * for (Object keys : inputMap.keySet()) {
 * 
 * checkDigit = 1; inputSchema = "" + inputMap.get(keys).toString();
 * 
 * JSONObject jsonParseObject = new JSONObject((Map)
 * validationMap.get(keys.toString()));
 * 
 * for (Object object1 : jsonParseObject.keySet()) {
 * 
 * changeMap.put(object1.toString(), jsonParseObject.get(object1.toString()));
 * 
 * }
 * 
 * if (jsonParseObject.keySet().size() != changeMap.keySet().size()) {
 * changeMap.remove(new ArrayList<>(changeMap.keySet()).get(changeMap.size() -
 * 1)); } valueChangeMap.put(keys.toString(), changeMap); validationValueMap =
 * valueChangeMap.get(keys.toString());
 * 
 * if (keys.equals("routingEntity")) {
 * 
 * for (Object obj : validationValueMap.keySet()) {
 * 
 * if (obj.equals("enum")) {
 * 
 * JSONArray array = (JSONArray) validationValueMap.get(obj); for (int i = 0; i
 * < array.size(); i++) { if (inputSchema.equals(array.get(i))) { checkDigit =
 * 0; break; } } if (checkDigit == 0) checkDigit = 1; else { checkDigit = 0;
 * result = (String) keys; } } else if (obj.equals("pattern")) {
 * validationString = (String) validationValueMap.get(obj);
 * 
 * if (!Pattern.matches(validationString, inputSchema)) {
 * 
 * result = (String) keys; break; }
 * 
 * } }
 * 
 * } else {
 * 
 * for (Object obj : validationValueMap.keySet()) {
 * 
 * if (obj.equals("enum")) {
 * 
 * JSONArray array = (JSONArray) validationValueMap.get(obj); for (int i = 0; i
 * < array.size(); i++) { if (inputSchema.equals(array.get(i))) { checkDigit =
 * 0; break; } } if (checkDigit == 0) checkDigit = 1; else { checkDigit = 0;
 * result += (String) keys + " "; } } else if (obj.equals("pattern")) {
 * validationString = (String) validationValueMap.get(obj);
 * 
 * if (!Pattern.matches(validationString, inputSchema)) {
 * 
 * 
 * result += (String) keys + " "; break; }
 * 
 * }
 * 
 * }
 * 
 * }
 * 
 * if (keys.equals("dateAndTime") && (!result.contains("dateAndTime"))) {
 * 
 * if (isLegalDate(inputSchema, "MMddHHmmss")){ fd.message.addInDeMap(7,
 * inputSchema);
 * 
 * } else { fd.message.addInDeMap(39, ResCode.resCode.get(respCodeStr + keys));
 * log.info(corrId + "Illegal data in Tag dateAndTime"); } }
 * 
 * }
 * 
 * ArrayList<String> requiredList = (ArrayList) validationMap.get("required");
 * for (int i = 0; i < requiredList.size(); i++) {
 * 
 * if (inputMap.get(requiredList.get(i)) != null) {
 * requiredList.remove("recipient"); } else { fd.message.addInDeMap(39,
 * ResCode.resCode.get(respCodeStr + requiredList.get(i))); log.info(corrId +
 * "Tag dateAndTime is missing"); } } if (result.contains("routingEntity")) {
 * 
 * exceptionList.add("routingEntity"); } else if (result.contains("transType"))
 * exceptionList.add("transType"); else exceptionList.add(result.split(" ")[0]);
 * 
 * if (exceptionList != null) { fd.message.addInDeMap(39,
 * ResCode.resCode.get(respCodeStr + exceptionList.get(0))); log.info(corrId +
 * "Illegal data in Tag "+exceptionList.get(0));
 * 
 * }
 * 
 * if(result == null){
 * 
 * fd.setNetworkId(routingEntity.toUpperCase()); NetworkRouting networkRoute =
 * NetworkHashData.routingMap.get(inputSchema.toUpperCase());
 * 
 * 
 * if (networkRoute != null) { fd.setInstRouting(networkRoute); msgType =
 * networkRoute.getNetworkFormat().charAt(0);
 * 
 * } else { fd.message.addInDeMap(39, ResCode.resCode.get(respCodeStr +
 * "routingEntity")); log.info(corrId + "RoutingEntity not found"); }
 * networkRouting = networkRoute;
 * 
 * fd = new ValidationCheck().populatePCode(fd, networkRouting, txnType,
 * accType, routingEntity.toUpperCase(), false, corrId);
 * 
 * }
 * 
 * return fd;
 * 
 * 
 * 
 */
