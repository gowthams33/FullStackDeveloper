package com.json.gson;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;
import com.json.method.JsonMethod;

@SuppressWarnings({ "rawtypes", "unchecked" })
public class JsonGsonJar extends JsonMethod {

	public GsonBuilder builder;
	public Gson gson;
	public Map<String,String> inputMap = new HashMap<>();
	public ArrayList<String> inputList = new ArrayList<>();
	/*
	 * @SuppressWarnings({ "unchecked", "rawtypes", "resource" })
	 * 
	 * @Override public void insertMapValue() {
	 * 
	 * Map map = new HashMap<>(); map.put("UserName", new
	 * Scanner(System.in).next()); map.put("Pin", new
	 * Scanner(System.in).nextLong()); map.put("Issuer", new
	 * Scanner(System.in).next()); map.put("Amount", new
	 * Scanner(System.in).nextInt());
	 * 
	 * builder = new GsonBuilder(); builder.setPrettyPrinting(); gson =
	 * builder.create();
	 * 
	 * String temp = gson.toJson(map);
	 * 
	 * System.out.println(temp);
	 * 
	 * try { FileWriter writer = new FileWriter("Input.json");
	 * writer.write(temp); writer.flush(); writer.close(); } catch (IOException
	 * e) { e.printStackTrace(); } }
	 *
	 *
	 * 
	 * @SuppressWarnings({ "resource", "unchecked", "rawtypes" }) public String
	 * insertArrayValue() {
	 * 
	 * ArrayList list = new ArrayList<>(); System.out.println("Enter UserName "
	 * ); list.add(new Scanner(System.in).next());
	 * 
	 * System.out.println("Enter Pin "); list.add(new
	 * Scanner(System.in).nextLong());
	 * 
	 * System.out.println("Enter Issuer "); list.add(new
	 * Scanner(System.in).next());
	 * 
	 * System.out.println("Enter Account Balance "); list.add(new
	 * Scanner(System.in).nextInt());
	 * 
	 * gson = new GsonBuilder().create(); String text = gson.toJson(list);
	 * System.out.println(text); // TempBeanClass class1 = gson.fromJson(text,
	 * TempBeanClass.class); // System.out.println(class1); return text; }
	 */
	
	@Override
	public void nestedJsonValueMethod(Object jsonObject, Map nestedValue) {

		builder = new GsonBuilder();
		gson = builder.create();
	
		Map jsonMap = gson.fromJson( gson.toJson(jsonObject), Map.class);

		for (Object keys : jsonMap.keySet())
			if (jsonMap.get(keys.toString()) instanceof Map) {
				nestedJsonValueMethod(jsonMap.get(keys.toString()), nestedValue);
			} else
				nestedValue.put(keys.toString(), "" + jsonMap.get(keys.toString()));
	}

	@Override
	public void nestedJsonValueMethod(Object jsonObject, ArrayList<String> nestedList) {

		builder = new GsonBuilder();
		gson = builder.create();
		
		Map jsonMap = gson.fromJson( gson.toJson(jsonObject), Map.class);
		for (Object objectTemp : jsonMap.keySet()) {
			if (jsonMap.get(objectTemp.toString()) instanceof Map) {
				nestedJsonValueMethod(jsonMap.get(objectTemp), nestedList);

			} else if (jsonMap.get(objectTemp) instanceof Collection) {
				nestedList.add(jsonMap.get(objectTemp).toString());
			} else
				nestedList.add("" + jsonMap.get(objectTemp.toString()));

		}

	}

	@Override
	public Map getJsonValue(File fileName) {

		
		try {
			Object object = new Gson().fromJson(new FileReader(fileName), Object.class);

			new JsonGsonJar().nestedJsonValueMethod(object, inputMap);
		} catch (JsonIOException | JsonSyntaxException | FileNotFoundException e) {
			e.printStackTrace();
		}
		return inputMap;
	}

	@Override
	public List getArrayValue(StringBuffer buffer) {

		Object object = new Gson().fromJson("" + buffer, Object.class);

		new JsonGsonJar().nestedJsonValueMethod(object, inputList);

		return inputList;
	}

}
