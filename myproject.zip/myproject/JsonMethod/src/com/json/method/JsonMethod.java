package com.json.method;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public abstract class JsonMethod {

	@SuppressWarnings("rawtypes")
	public abstract void nestedJsonValueMethod(Object jsonObject, Map nestedJsonValue);

	public abstract void nestedJsonValueMethod(Object jsonObject, ArrayList<String> nestedJsonArray);

	@SuppressWarnings("rawtypes")
	public abstract Map getJsonValue(File fileName);
	
	@SuppressWarnings("rawtypes")
	public abstract Map getJsonValue(String value);

	@SuppressWarnings("rawtypes")
	public abstract List getArrayValue(StringBuffer fileLocation);
	
	

}
