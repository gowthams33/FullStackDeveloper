package com.prt.privateClass;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Access {

	public static void main(String[] args) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		// TODO Auto-generated method stub
		PrivateAccess access = new PrivateAccess();
		Method method = PrivateAccess.class.getDeclaredMethod("display",String.class);
		method.setAccessible(true);
		String value = (String) method.invoke(access, "private");
		System.out.println(value);
	}

}
