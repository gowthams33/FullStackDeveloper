package com.prt.privateClass;

public class PrivateAccess {
	
	@SuppressWarnings("unused")
	private static String display(String name ){
		return name;
	}

}
