package com.prt.IP;

import java.net.InetAddress;

public class IPAddress {

	public static void main(String[] args) {
	
		try {
		
			
			// Iterate all IP addresses assigned to each card...
			
	        // At this point, we did not find a non-loopback address.
	        // Fall back to returning whatever InetAddress.getLocalHost() returns...
			InetAddress jdkSuppliedAddress = InetAddress.getLocalHost();
			
			if (jdkSuppliedAddress != null) {
				System.out.println("IP address->"+jdkSuppliedAddress.getHostAddress());
			}
			System.out.println(jdkSuppliedAddress.getHostAddress());			
	    } catch (Exception e) {
	        
	    }
		

	}

}
			