package com.Json.Exception;

public class CheckDigit {

	public static void main(String[] args) {

		int i1 = 0;

		inner: for (i1 = 0; i1 <= 10; i1++) {
			if (i1 == 9)
				break inner;
			else
				System.out.println(i1);
		}
		System.out.println("\n\n");
		long start = System.nanoTime();
		String integer = "4679370303836265";
		char[] cs = integer.toCharArray();
		int sum = 0;
		for (int i = 0; i < cs.length - 1; i++) {
			int val = (cs[i] - 48);
			if (i % 2 == 0)
				if ((val * 2) >= 10)
					sum += ((val * 2) % 10 + (val * 2) / 10);
				else
					sum += val * 2;
			else
				sum += val;

		}
		sum = 10 - sum % 10;
		System.out.println(sum);
		long end = System.nanoTime();
		System.out.println(end - start);
	}

}
