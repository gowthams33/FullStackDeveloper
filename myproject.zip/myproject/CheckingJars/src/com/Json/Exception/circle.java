package com.Json.Exception;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Pattern;

public class circle {

	static final Map<String, String> tag;

	static {
		HashMap<String, String> tagValue = new HashMap<>();
		tagValue.put("currency", "recipient.currency");
		tagValue.put("nameOnAccount", "recipient.nameOnAccount");
		tagValue.put("firstName", "recipient.firstName");
		tagValue.put("lastName", "recipient.lastName");
		tagValue.put("dateOfBirth", "recipient.dateOfBirth");
		tagValue.put("phone", "recipient.phone");
		tagValue.put("email", "recipient.email");
		tagValue.put("statementDescriptor", "recipient.statementDescriptor");

		tagValue.put("address", "recipient.address");
		tagValue.put("city", "recipient.address.city");
		tagValue.put("line1", "recipient.address.line1");
		tagValue.put("countrySubdivision", "recipient.address.countrySubdivision");
		tagValue.put("postalCode", "recipient.address.postalCode");
		tagValue.put("country", "recipient.address.country");
		tag = Collections.unmodifiableMap(tagValue);
	}

	public static void main(String[] args) {
		System.out.println(tag);
		System.out.println("-----file date check-----");
		File f = new File("F:\\Json\\validation files\\transaction.request.json");
		System.out.println(new SimpleDateFormat("MM/dd/yyyy").format(f.lastModified()));
		if((new SimpleDateFormat("MM/dd/yyyy").format(f.lastModified())).compareTo(new SimpleDateFormat("MM/dd/yyyy").format(f.lastModified())) > 0)
			System.out.println("equal date ");
		System.out.println("-----check string function");
		
		// --------check----------
		String vaslue = "";
		String value = "String";

		if (vaslue.getClass() == value.getClass())
			System.out.println(vaslue.getClass().getSimpleName());
		long l = 0707;
		String value1 = "" + l;
		System.out.println(Pattern.matches("^(0?[1-9]|1[0-2])(0?[1-9]|[12][0-9]|3[01])$", value1));

		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);

		String input = scanner.next();
		String temp = "";

		int count = 1;
		for (int i = 0; i < input.length() / 2; i++) {
			if (input.charAt(i) != input.charAt(input.length() - (i + 1)))
				count = 0;
		}
		if (count == 1)
			System.out.println("Palindrome");
		else {
			count = 1;
			for (int i = 0; i < input.length() / 2;) {
				temp = "" + input.charAt(i);
				if (input.charAt(i) != input.charAt(input.length() - (i + 1)) && i == 0)
					input = input.substring(i + 1) + temp;
				else
					i++;
			}

			for (int i = 0; i < input.length() / 2; i++) {
				if (input.charAt(i) != input.charAt(input.length() - (i + 1)))
					count = 0;
			}
		}
		if (count == 1)
			System.out.println("circle palindrome");
		else
			System.out.println("neither palindrome ner circle palindrome");

	}

}
