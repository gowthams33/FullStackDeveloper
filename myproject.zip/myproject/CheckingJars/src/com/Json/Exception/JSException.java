package com.Json.Exception;

import java.util.ArrayList;

@SuppressWarnings("serial")
public class JSException extends Exception {

	ArrayList<String> list = new ArrayList<>();
	public JSException(String value,String valueOne) {
		list.add("Input String "+value+" is not Equal For Validation Case:"+valueOne);
		
	}

}
