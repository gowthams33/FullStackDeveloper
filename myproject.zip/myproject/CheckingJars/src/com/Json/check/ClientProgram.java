package com.Json.check;

import java.io.File;
import java.util.ArrayList;

import com.json.simple.JsonSimpleJar;

public class ClientProgram {

	public static ArrayList<String> list = new ArrayList<String>();

	public static void main(String[] fileLocation) {

		long start = System.currentTimeMillis();
		
		JsonSimpleJar jsonSimple = new JsonSimpleJar();
		
	

		// validation by files from command line argument..

		File input = new File(fileLocation[0]);
		File validation = new File(fileLocation[1]);

		list.addAll(new JsonCheck().jsonMethodCheck(jsonSimple, input, validation));

		System.out.println(list);

		long end = System.currentTimeMillis();
		System.out.println((end - start));

	}
}
