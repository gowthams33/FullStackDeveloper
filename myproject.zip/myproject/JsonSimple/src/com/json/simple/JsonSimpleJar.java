package com.json.simple;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.json.method.JsonMethod;

@SuppressWarnings({ "rawtypes", "unchecked" })
public class JsonSimpleJar extends JsonMethod {

	public JSONParser parser = null;
	public Map<String, String> inputMap = null;
	public ArrayList<String> inputList = null;

	/**
	 * @SuppressWarnings({ "unchecked", "rawtypes", "resource" })
	 * 
	 * @Override public void insertMapValue() {
	 * 
	 *           Map map = new HashMap<>(); map.put("UserName", new
	 *           Scanner(System.in).next()); map.put("Pin", new
	 *           Scanner(System.in).nextLong()); map.put("Issuer", new
	 *           Scanner(System.in).next()); map.put("Amount", new
	 *           Scanner(System.in).nextInt());
	 * 
	 *           JSONObject object = new JSONObject(map);
	 * 
	 *           try { FileWriter writer = new FileWriter("Input.json");
	 *           writer.write(object.toString()); writer.flush();
	 *           writer.close(); System.out.println(writer); } catch
	 *           (IOException e) {
	 * 
	 *           e.printStackTrace(); }
	 * 
	 *           }
	 */

	
	@Override
	/**
	 * Get Input Json file from client to parser into java map..
	 */
	// Reading the json file from user and parse
	public Map getJsonValue(File reader) {

		try {

			parser = new JSONParser();
			inputMap = new HashMap<String, String>();
			Object object = parser.parse(new FileReader(reader));

			new JsonSimpleJar().nestedJsonValueMethod(object, inputMap);

		} catch (ParseException | IOException e) {
			e.printStackTrace();

		}
		
		return inputMap;
	}

	@Override
	/**
	 * Json file objects and arrays are presented in nested form and map
	 * conversion..
	 */
	//nested object and array in json file call this method itself
	public void nestedJsonValueMethod(Object key, Map nestedMap) {

		JSONObject arrayObject = (JSONObject) key;

		for (Object keyValue : arrayObject.keySet()) {

			if (arrayObject.get(keyValue.toString()) instanceof JSONObject) {
				nestedJsonValueMethod((JSONObject) arrayObject.get(keyValue.toString()), nestedMap);
			
			} else if (arrayObject.get(keyValue.toString()) instanceof JSONArray) {
				if(nestedMap.containsKey(keyValue))
					nestedMap.put(keyValue, nestedMap.get(keyValue));
				nestedMap.put(keyValue.toString(), new JsonSimpleJar().getArrayValue(new StringBuffer("" + arrayObject.get(keyValue.toString()))));
			
			} else {
				nestedMap.put(keyValue.toString(), arrayObject.get(keyValue.toString()));

			}

		}

	}

	/**
	 * Json file input values presented in nested form and arraylist conversion
	 */
	//nested array in json file call this method itself
	public void nestedJsonValueMethod(Object key, ArrayList<String> list) {

		JSONArray array = (JSONArray) key;
		for (Object arrayValue : array) {
			if (arrayValue instanceof String) {
				list.add(arrayValue.toString());
				
			} else {
				
				JSONObject arrayObject = (JSONObject) arrayValue;
				for (Object obj : arrayObject.keySet()) {

					if (arrayObject.get(obj.toString()) instanceof JSONObject)
						nestedJsonValueMethod(arrayObject.get(obj.toString()), list);
					else if (arrayObject.get(obj.toString()) instanceof JSONArray)
						new JsonSimpleJar().getArrayValue(new StringBuffer("" + arrayObject.get(obj.toString())));
					else
						list.add("" + arrayObject.get(obj.toString()));
				}
			}
		}

	}

	@Override
	/**
	 * 
	 * This method get input as json arrays and convert to java arraylist
	 * 
	 */
	//reading the json file array values
	public List getArrayValue(StringBuffer fileLocation) {

		try {
			parser = new JSONParser();
			inputList = new ArrayList<>();
			JSONArray array = (JSONArray) parser.parse("" + fileLocation.toString());

			new JsonSimpleJar().nestedJsonValueMethod(array, inputList);
		} catch (ParseException e) {

			e.printStackTrace();
		}

		return inputList;
	}

	@Override
	public Map getJsonValue(String value) {
		parser = new JSONParser();
		inputMap = new HashMap<String, String>();
		Object object;
		try {
			object = parser.parse(value);
			new JsonSimpleJar().nestedJsonValueMethod(object, inputMap);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return inputMap;
	}

}
